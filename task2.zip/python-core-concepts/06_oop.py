"""Concept 6: Classes and objects (OOP basics)."""


class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

    def average(self):
        return sum(self.marks) / len(self.marks)

    def __str__(self):
        return f"{self.name} (average: {self.average():.1f})"


class InternStudent(Student):
    """Inheritance example."""

    def __init__(self, name, marks, company):
        super().__init__(name, marks)
        self.company = company

    def __str__(self):
        return f"{super().__str__()} - intern at {self.company}"


if __name__ == "__main__":
    s1 = Student("Asha", [80, 90, 70])
    s2 = InternStudent("Rutuja", [85, 95, 90], "Yuva Intern")
    print(s1)
    print(s2)
