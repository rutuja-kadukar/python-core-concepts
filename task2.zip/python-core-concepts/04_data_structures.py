"""Concept 4: Lists, tuples, sets and dictionaries."""

# List (ordered, changeable)
fruits = ["apple", "banana", "mango"]
fruits.append("orange")
fruits.remove("banana")
print("List:", fruits, "| length:", len(fruits))

# Tuple (ordered, fixed)
point = (10, 20)
print("Tuple:", point, "| x =", point[0])

# Set (unique values)
numbers = {1, 2, 2, 3, 3, 3}
print("Set:", numbers)

# Dictionary (key -> value)
student = {"name": "Rutuja", "course": "Python", "marks": 88}
student["city"] = "Pune"
for key, value in student.items():
    print(f"{key}: {value}")

# List comprehension and sorting
marks = [45, 82, 67, 91, 58]
passed = [m for m in marks if m >= 60]
print("Passed:", sorted(passed, reverse=True))
