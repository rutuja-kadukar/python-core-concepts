"""Concept 3: Functions."""


def greet(name, greeting="Hello"):
    """Return a greeting message (default argument example)."""
    return f"{greeting}, {name}!"


def is_even(number):
    return number % 2 == 0


def factorial(n):
    """Recursive factorial."""
    if n <= 1:
        return 1
    return n * factorial(n - 1)


def stats(numbers):
    """Return minimum, maximum and average of a list."""
    return min(numbers), max(numbers), sum(numbers) / len(numbers)


if __name__ == "__main__":
    print(greet("Rutuja"))
    print(greet("Rutuja", "Welcome"))
    print("Is 10 even?", is_even(10))
    print("Factorial of 5:", factorial(5))
    low, high, avg = stats([10, 20, 30, 40])
    print(f"Min={low}, Max={high}, Average={avg}")
