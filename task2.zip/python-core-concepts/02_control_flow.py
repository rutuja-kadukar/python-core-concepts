"""Concept 2: Conditions and loops."""

# if / elif / else
marks = 72
if marks >= 75:
    grade = "A"
elif marks >= 60:
    grade = "B"
else:
    grade = "C"
print(f"Marks {marks} -> Grade {grade}")

# for loop
print("Squares:", [n * n for n in range(1, 6)])
for n in range(1, 4):
    print("Number", n)

# while loop
count = 3
while count > 0:
    print("Countdown:", count)
    count -= 1

# FizzBuzz (1 to 15)
for i in range(1, 16):
    if i % 15 == 0:
        print("FizzBuzz")
    elif i % 3 == 0:
        print("Fizz")
    elif i % 5 == 0:
        print("Buzz")
    else:
        print(i)
