"""Concept 1: Variables, data types and input/output."""

name = "Intern"          # str
score = 85               # int
price = 99.5             # float
is_active = True         # bool

print("Name:", name, "| type:", type(name).__name__)
print("Score:", score, "| type:", type(score).__name__)
print("Price:", price, "| type:", type(price).__name__)
print("Active:", is_active, "| type:", type(is_active).__name__)

# Type conversion and arithmetic
total = score + price
print("Total:", total)
print("Score as text:", str(score) + " marks")
print("Floor division:", 17 // 5, "| Remainder:", 17 % 5, "| Power:", 2 ** 5)

# f-string formatting
print(f"{name} scored {score} and the price is {price:.2f}")
