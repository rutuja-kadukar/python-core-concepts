"""Concept 7: Error handling with try / except / finally."""


def safe_divide(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("Error: cannot divide by zero.")
        return None
    else:
        return result
    finally:
        print("Division attempted.")


def to_number(text):
    try:
        return int(text)
    except ValueError:
        print(f"Error: '{text}' is not a valid number.")
        return None


if __name__ == "__main__":
    print(safe_divide(10, 2))
    print(safe_divide(5, 0))
    print(to_number("42"))
    print(to_number("abc"))
