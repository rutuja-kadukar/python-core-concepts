# Python Core Concepts

Small programs created for Task 2 (Core Concepts and Skills) of the Python Developer internship.

| File | Concept |
|---|---|
| `01_basics.py` | Variables, data types, input/output |
| `02_control_flow.py` | if/elif/else, for and while loops, FizzBuzz |
| `03_functions.py` | Functions, default arguments, recursion |
| `04_data_structures.py` | Lists, tuples, sets, dictionaries |
| `05_file_handling.py` | Reading and writing files |
| `06_oop.py` | Classes, objects, inheritance |
| `07_error_handling.py` | try / except / finally |
| `todo_app.py` | Mini project: command-line To-Do list |

## How to run

```
python 01_basics.py
python todo_app.py
```

Requires Python 3.8 or newer. No external libraries needed.
