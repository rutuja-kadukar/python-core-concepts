"""Concept 5: Reading and writing files."""

FILE_NAME = "notes.txt"

# Write (creates or overwrites the file)
with open(FILE_NAME, "w", encoding="utf-8") as f:
    f.write("Line 1: Python file handling\n")
    f.write("Line 2: Using the with statement\n")

# Append
with open(FILE_NAME, "a", encoding="utf-8") as f:
    f.write("Line 3: Appended text\n")

# Read
with open(FILE_NAME, "r", encoding="utf-8") as f:
    for number, line in enumerate(f, start=1):
        print(number, line.strip())
