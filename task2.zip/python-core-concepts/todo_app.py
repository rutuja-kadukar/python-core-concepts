"""Mini project: command-line To-Do list.

Combines functions, lists, dictionaries, file handling (JSON),
loops, conditions and error handling.
"""
import json

DATA_FILE = "tasks.json"


def load_tasks():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def save_tasks(tasks):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2)


def show_tasks(tasks):
    if not tasks:
        print("No tasks yet.")
        return
    for i, task in enumerate(tasks, start=1):
        mark = "x" if task["done"] else " "
        print(f"{i}. [{mark}] {task['title']}")


def main():
    tasks = load_tasks()
    while True:
        print("\n1) Add  2) List  3) Mark done  4) Delete  5) Quit")
        choice = input("Choose: ").strip()
        if choice == "1":
            title = input("Task title: ").strip()
            if title:
                tasks.append({"title": title, "done": False})
                save_tasks(tasks)
                print("Task added.")
        elif choice == "2":
            show_tasks(tasks)
        elif choice in ("3", "4"):
            show_tasks(tasks)
            try:
                index = int(input("Task number: ")) - 1
                if choice == "3":
                    tasks[index]["done"] = True
                    print("Marked as done.")
                else:
                    removed = tasks.pop(index)
                    print(f"Deleted: {removed['title']}")
                save_tasks(tasks)
            except (ValueError, IndexError):
                print("Invalid task number.")
        elif choice == "5":
            print("Goodbye!")
            break
        else:
            print("Please choose 1-5.")


if __name__ == "__main__":
    main()
